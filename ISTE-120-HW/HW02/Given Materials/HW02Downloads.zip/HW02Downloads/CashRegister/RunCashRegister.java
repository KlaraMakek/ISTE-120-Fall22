
public class RunCashRegister {
   public static void main(String[] args) {
   }
}
