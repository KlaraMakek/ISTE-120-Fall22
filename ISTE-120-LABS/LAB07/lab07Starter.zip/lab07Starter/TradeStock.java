import java.util.Scanner;

/**
 * TradeStock - class to exercise the Stock class.
 * @author  D. Patric (adapted from J. Leone/R. Niemi
 * @version 2201
 */

public class TradeStock {
   public static void main(String[] args) {
      // declarations
      Scanner in = new Scanner(System.in);
      String name;   //Name of stock
      String symbol; //Symbol of stock
      double price;  //price per share of stock
      int shares;    //number of shares of stock
      
      // get name and symbol
      System.out.print("Enter name of stock: ");
      name = in.nextLine();
      System.out.print("Enter symbol of stock: ");
      symbol = in.nextLine();
      
      // instantiate Stock object with price and symbol
      Stock myStock = new Stock(name, symbol);
      
      // prompt user for price and set it
      System.out.print("Enter price of stock: ");
      price = in.nextDouble();
      myStock.setPrice(price);
      
      // prompt user for number of shares and set it
      System.out.print("Enter number of shares: ");
      shares = in.nextInt();
      myStock.setShares(shares);
      
      // print stock info using spaces with each output
      System.out.printf("%nName:   %s%n", myStock.getName());
      System.out.printf("Symbol: %s%n", myStock.getSymbol());
      System.out.printf("Price:  %.2f%n", myStock.getPrice());
      System.out.printf("Shares: %d%n", myStock.getShares());
   }
}